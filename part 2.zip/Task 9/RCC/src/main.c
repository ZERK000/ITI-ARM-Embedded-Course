#include "STD_TYPES.h"
#include <EXTI_Interface.h>
#include <EXTI_Private.h>
#include <GPIO_Interface.h>
#include <MNVIC_Interface.h>
#include <MNVIC_Private.h>
#include <RCCInterface.h> // this should include Interface.h
#include <Systick_Interface.h>
#include "UART_Interface.h"
#include "SevenSegment.h"
#include "CommonMacros.h"
#include "abba.h"

//extern const unsigned char abba_raw[];
//extern const unsigned int abba_raw_len;

#define LED_PIN      7
#define BUZZER_PIN   8
#define TX_PIN       9
#define RX_PIN       10

volatile u8 RecievedData = 99;
volatile u8 NewCommandRecieved = 0;

void PlayMusic();
void StartCounter();
void FlashLED();

int main(void) {

	RCC_SetClock(HSI_ON, ENABLE);    // Optionally disable HSI
	RCC_EnablePeripheralClock(AHB1, RCC_AHB1_GPIOA);
	RCC_EnablePeripheralClock(AHB1, RCC_AHB1_GPIOB);
	RCC_EnablePeripheralClock(APB2, RCC_APB2_USART1);

	// set pin mode for PORTA pins 0-6 for seven segment
	SEGMENT_voidInit();

	// set led pin mode
	GPIO_PinMode(PORTA, LED_PIN, OUTPUT);
	GPIO_PinMode(PORTA, BUZZER_PIN, OUTPUT);

	// Initialize Music pins
	GPIO_PinMode(PORTB, 0, OUTPUT);
	GPIO_PinMode(PORTB, 1, OUTPUT);
	GPIO_PinMode(PORTB, 2, OUTPUT);
	GPIO_PinMode(PORTB, 3, OUTPUT);
	GPIO_PinMode(PORTB, 4, OUTPUT);
	GPIO_PinMode(PORTB, 5, OUTPUT);
	GPIO_PinMode(PORTB, 6, OUTPUT);
	GPIO_PinMode(PORTB, 7, OUTPUT);

	// Initialize UART
	GPIO_PinMode(PORTA, TX_PIN, ALT_FUNCTION);
	GPIO_PinMode(PORTA, RX_PIN, ALT_FUNCTION);
	GPIO_SetAlternativeConfiguration(PORTA,9 ,AF7);
	GPIO_SetAlternativeConfiguration(PORTA,10 ,AF7);





	SET_BIT(USART1->CR1, 5); // Enable RXNEIE (Receive interrupt enable)
	UART_voidInit();
	MNVIC_voidEnable(USART1_IRQn);
	__asm volatile ("cpsie i");

	// Initialize SYSTick for delays
	MSTK_voidInit();


	while (1)
	{
		if (NewCommandRecieved)
		{
			NewCommandRecieved = 0;  // Reset flag

			switch (RecievedData - '0') {
			case 0: GPIO_SetPinValue(PORTA, LED_PIN, HIGH); break;
			case 1: GPIO_SetPinValue(PORTA, LED_PIN, LOW); break;
			case 2: PlayMusic(); break;
			case 3:  break; // stop music, handled in PlayMusic Function
			case 4: StartCounter(); break;
			case 5: SEGMENT_voidCloseAllSegments(); break;
			case 6: GPIO_SetPinValue(PORTA, BUZZER_PIN, HIGH); break;
			case 7: GPIO_SetPinValue(PORTA, BUZZER_PIN, LOW);  break;
			case 8:
				GPIO_SetPinValue(PORTA, LED_PIN, LOW);
				GPIO_SetPinValue(PORTA, BUZZER_PIN, LOW);
				SEGMENT_voidCloseAllSegments();
				break;
			case 9: FlashLED(); break;
			default: break;
			}
		}
	}
}




void USART1_IRQHandler(void)
{
	if (GET_BIT(USART1->SR, 5))  // RXNE
	{
		RecievedData = USART1->DR;  // Read received byte
		NewCommandRecieved = 1;  // Signal new command
	}
}


void PlayMusic()
{
	for (int i = 0; (unsigned) i < abba_raw_len; i++)
	{
		GPIOB->ODR = (GPIOA->ODR & 0xFF00) | abba_raw[i];
		MSTK_voidDelayus(125);
		if(NewCommandRecieved)
			break;
		if((!NewCommandRecieved) && (i == abba_raw_len - 1))
			i =0;
	}
}


void StartCounter()
{
	for (int i =0; i<=9; i++)
	{
		SEGMENT_voidDisplayDigit(i);

		if(NewCommandRecieved)
			break;
		MSTK_voidDelayms(500);
	}
}


void FlashLED()
{
	while(1)
	{
		GPIO_SetPinValue(PORTA, LED_PIN, HIGH);
		MSTK_voidDelayms(1000);
		GPIO_SetPinValue(PORTA, LED_PIN, LOW);
		MSTK_voidDelayms(1000);
		if(NewCommandRecieved)
			break;
	}
}
