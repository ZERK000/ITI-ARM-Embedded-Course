/*
 * SevenSegment.h
 *
 *  Created on: Jul 16, 2025
 *      Author: Ziad
 */

#ifndef SEVENSEGMENT_H_
#define SEVENSEGMENT_H_

#include "STD_TYPES.h"
#include "GPIO_Interface.h"


// Define your segment pins
#define SEG_A_PIN   0
#define SEG_B_PIN   1
#define SEG_C_PIN   2
#define SEG_D_PIN   3
#define SEG_E_PIN   4
#define SEG_F_PIN   5
#define SEG_G_PIN   6





// Initializes the pins connected to the 7-segment display
void SEGMENT_voidInit(void);

// Displays a digit (0�9)
void SEGMENT_voidDisplayDigit(u8 Digit);

void SEGMENT_voidCloseAllSegments();



#endif /* SEVENSEGMENT_H_ */
