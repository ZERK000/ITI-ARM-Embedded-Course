import tkinter as tk
import speech_recognition as sr
import serial
import time
import threading

# === Serial Setup ===
arduino = serial.Serial(port='COM10', baudrate=9600, timeout=1)
time.sleep(2)

# === Command Mapping ===
command_map = {
    "turn on led": 0,
    "turn off led": 1,
    "play the music": 2,
    "stop the music": 3,
    "start the counter": 4,
    "stop the counter": 5,
    "start the alarm": 6,
    "stop the alarm": 7,
    "turn everything off": 8,
    "flash led": 9
}

# === Speech Recognition Setup ===
recognizer = sr.Recognizer()
mic = sr.Microphone()

# === GUI Setup ===
root = tk.Tk()
root.title("Arduino Voice Control")
root.geometry("600x300")
root.config(bg="#f2f2f2")

# === Fonts and Styles ===
title_font = ("Helvetica", 16, "bold")
label_font = ("Helvetica", 12)
button_font = ("Helvetica", 12, "bold")

# === Frames ===
main_frame = tk.Frame(root, bg="#f2f2f2", padx=20, pady=20)
main_frame.pack(expand=True, fill="both")

left_frame = tk.Frame(main_frame, bg="#f2f2f2")
left_frame.pack(side="left", fill="y", padx=10)

right_frame = tk.Frame(main_frame, bg="#f2f2f2")
right_frame.pack(side="right", expand=True, fill="both", padx=10)

# === Title and Output ===
title_label = tk.Label(right_frame, text="Voice Control Panel", font=title_font, bg="#f2f2f2")
title_label.pack(pady=(0, 20))

text_display = tk.StringVar()
text_display.set("Recognized command will appear here.")
output_label = tk.Label(right_frame, textvariable=text_display, font=label_font, fg="#004080", bg="#f2f2f2", wraplength=300)
output_label.pack(pady=10)

status = tk.StringVar()
status.set("Waiting for command...")
status_label = tk.Label(right_frame, textvariable=status, font=("Helvetica", 10), fg="green", bg="#f2f2f2")
status_label.pack()

# === Button ===
def on_button_click():
    threading.Thread(target=recognize_and_send).start()

listen_button = tk.Button(right_frame, text="🎙️ Start Listening", command=on_button_click, font=button_font, bg="#4CAF50", fg="white", padx=20, pady=10, relief="raised", bd=3)
listen_button.pack(pady=15)

# === Available Commands List ===
commands_title = tk.Label(left_frame, text="Available Commands:", font=label_font, bg="#f2f2f2", anchor="w")
commands_title.pack(anchor="w")

for cmd in command_map.keys():
    tk.Label(left_frame, text="• " + cmd, font=("Helvetica", 10), bg="#f2f2f2", anchor="w").pack(anchor="w")

# === Speech Function ===
def recognize_and_send():
    with mic as source:
        recognizer.adjust_for_ambient_noise(source)
        text_display.set("Listening...")
        status.set("Listening... 🎧")
        try:
            audio = recognizer.listen(source, timeout=5)
        except sr.WaitTimeoutError:
            text_display.set("No speech detected.")
            status.set("Try again.")
            return

    try:
        command_text = recognizer.recognize_google(audio).lower().strip()
        text_display.set(f"You said: {command_text}")

        if command_text in command_map:
            code = command_map[command_text]
            arduino.write(f"{code}\n".encode())
            status.set("Command sent ✅")
        else:
            text_display.set(f"Unknown command: '{command_text}'")
            status.set("Command not recognized ❌")
    except sr.UnknownValueError:
        text_display.set("Could not understand.")
        status.set("Try again.")
    except sr.RequestError:
        text_display.set("API error (check internet).")
        status.set("Connection error.")
    except Exception as e:
        text_display.set(f"Error: {str(e)}")
        status.set("Error occurred ❗")

# === Main Loop ===
root.mainloop()
