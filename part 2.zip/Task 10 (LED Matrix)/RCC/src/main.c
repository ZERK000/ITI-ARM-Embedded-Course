#include "STD_TYPES.h"
#include <EXTI_Interface.h>
#include <EXTI_Private.h>
#include "GPIO_Interface.h"
#include <MNVIC_Interface.h>
#include "MNVIC_Private.h"
#include "RCCInterface.h" // this should include Interface.h
#include "Systick_Interface.h"
#include "UART_Interface.h"
#include "SevenSegment.h"
#include "CommonMacros.h"
#include "LEDMatrix_Interface.h"







int main(void) {

	RCC_SetClock(HSI_ON, ENABLE);
	RCC_EnablePeripheralClock(AHB1, RCC_AHB1_GPIOA);
	RCC_EnablePeripheralClock(AHB1, RCC_AHB1_GPIOB);

//	u8 Columns[] = {0xE3, 0xE3, 0xF3, 0xD3, 0xDB, 0xCB, 0xCF, 0xC7};

	LEDMatrix_Init();
	MSTK_voidInit();

	const u8 TEXT[] = {
			// Z
			0x81, 0xC1, 0xA1, 0x91, 0x89, 0x85, 0x83, 0x81,
			// Space
			0x00, 0x00,
			// I
			0x00, 0x81, 0x81, 0xFF, 0x81, 0x81, 0x00, 0x00,
			// Space
			0x00, 0x00,
			// A
			0x7E, 0x11, 0x11, 0x11, 0x7E, 0x00, 0x00, 0x00,
			// Space
			0x00, 0x00,
			// D
			0xFF, 0x81, 0x81, 0x81, 0x66, 0x3C, 0x00, 0x00,
			// End spacing
			0x00, 0x00, 0x00, 0x00
	};

#define TEXT_LENGTH (sizeof(TEXT)/sizeof(TEXT[0]))

	u8 window[8];

	while (1)
	{
		for (u16 i = 0; i < TEXT_LENGTH - 8; i++) // slide window of 8 columns
		{
			for (u8 j = 0; j < 8; j++)
			{
				window[j] = TEXT[i + j];
			}

			LEDMatrix_Display(window);  // show current 8-column window
			MSTK_voidDelayms(20); // scrolling delay
		}
	}
}




