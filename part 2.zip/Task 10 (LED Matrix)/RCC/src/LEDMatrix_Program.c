/*
 * LEDMatrix_Program.c
 *
 *  Created on: Jul 29, 2025
 *      Author: Ziad
 */



#include "STD_TYPES.h"
#include "CommonMacros.h"
#include "GPIO_Interface.h"
#include "Systick_Interface.h"

#include "LEDMatrix_Config.h"
#include "LEDMatrix_Interface.h"

void LEDMatrix_Init()
{
	u8 Itterator = 0;

	for(Itterator =0; Itterator<13; Itterator++)
	{
		GPIO_PinMode(PORTA,Itterator,OUTPUT);
		GPIO_OutputPinConfigure(PORTA, Itterator, PUSH_PULL, LOW_SPEED);
	}
	for(Itterator =0; Itterator<3; Itterator++)
	{
		GPIO_PinMode(PORTB,Itterator,OUTPUT);
		GPIO_OutputPinConfigure(PORTB, Itterator, PUSH_PULL, LOW_SPEED);
	}

}

static void LEDMatrix_voidSetRowValue(u8 RowValue)
{
	u8 Itterator = 0;
	for(Itterator =0; Itterator<8; Itterator++)
	{
		GPIO_SetPinValue(PORTA,Itterator,GET_BIT(RowValue,Itterator));
	}
}

static void LEDMatrix_DeactivateAllColumns()
{
	u8 Itterator = 0;
	for(Itterator =8; Itterator<13; Itterator++)
	{
		GPIO_SetPinValue(PORTA,Itterator,1);
	}
	for(Itterator =0; Itterator<3; Itterator++)
	{
		GPIO_SetPinValue(PORTB,Itterator,1);
	}
}

void LEDMatrix_Display(u8* Array)
{
	u8 Iterrator =0;

	for(Iterrator =0; Iterrator<5; Iterrator++)
	{
		// set row value
		LEDMatrix_voidSetRowValue(Array[Iterrator]);

		GPIO_SetPinValue(PORTA, 8 + Iterrator,0);

		MSTK_voidDelayus(2500);

		LEDMatrix_DeactivateAllColumns();
	}

	for(Iterrator =0; Iterrator<3; Iterrator++)
	{
		// set row value
		LEDMatrix_voidSetRowValue(Array[Iterrator + 5]);

		GPIO_SetPinValue(PORTB,Iterrator,0);

		MSTK_voidDelayus(2500);

		LEDMatrix_DeactivateAllColumns();
	}




}
