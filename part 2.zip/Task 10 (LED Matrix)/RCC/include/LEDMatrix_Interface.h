/*
 * LEDMatrix_Interface.h
 *
 *  Created on: Jul 29, 2025
 *      Author: Ziad
 */

#ifndef LEDMATRIX_INTERFACE_H_
#define LEDMATRIX_INTERFACE_H_


void LEDMatrix_Init();

void LEDMatrix_Display(u8* LEDArray);




#endif /* LEDMATRIX_INTERFACE_H_ */
