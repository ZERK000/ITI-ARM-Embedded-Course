/*
 * WiFi_Interface.h
 *
 *  Created on: Jul 27, 2025
 *      Author: Ziad
 */

#ifndef WIFI_INTERFACE_H_
#define WIFI_INTERFACE_H_





#endif /* WIFI_INTERFACE_H_ */
