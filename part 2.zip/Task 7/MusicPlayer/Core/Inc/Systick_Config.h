/*
 * Systick_Config.h
 *
 *  Created on: Jul 16, 2025
 *      Author: Ziad
 */

#ifndef SYSTICK_CONFIG_H_
#define SYSTICK_CONFIG_H_


/*Choose Between
1-STK_AHB
2-STK_AHB_8*/
#define STK_SYSTEM_CLK   STK_AHB_8


#endif /* SYSTICK_CONFIG_H_ */
