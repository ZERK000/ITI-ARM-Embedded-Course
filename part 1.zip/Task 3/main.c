#include "RCCDriver.h" // this should include Interface.h
#include "GPIO_Interface.h"

int main(void) {
	RCC_SetClock(HSE_ON, ENABLE);     // Enable HSE
	RCC_SetClock(HSI_ON, ENABLE);    // Optionally disable HSI
	RCC_AHB1EnableClock(RCC_AHB1_GPIOA, ENABLE);


	GPIO_PinMode(PORTA, 5, OUTPUT);
	GPIO_OutputPinConfigure(PORTA, 5, PUSH_PULL, HIGH_SPEED);

	while (1)
	{
		GPIO_SetPinValueAtomic(PORTA, 5, HIGH);
		for (volatile u32 i = 0; i < 100000; i++);
		GPIO_SetPinValueAtomic(PORTA, 5, LOW);
		for (volatile u32 i = 0; i < 100000; i++);
	}
}
