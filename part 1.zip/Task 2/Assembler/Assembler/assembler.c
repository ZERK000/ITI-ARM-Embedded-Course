#include "Assembler.h"

InstructionLookup lookup_table[] = {
    { "AND", DataProcessing, AND },
    { "EOR", DataProcessing, EOR },
    { "SUB", DataProcessing, SUB },
    { "RSB", DataProcessing, RSB },
    { "ADD", DataProcessing, ADD },
    { "ADC", DataProcessing, ADC },
    { "SBC", DataProcessing, SBC },
    { "RSC", DataProcessing, RSC },
    { "TST", DataProcessing, TST },
    { "TEQ", DataProcessing, TEQ },
    { "CMP", DataProcessing, CMP },
    { "CMN", DataProcessing, CMN },
    { "ORR", DataProcessing, ORR },
    { "MOV", DataProcessing, MOV },
    { "BIC", DataProcessing, BIC },
    { "MVN", DataProcessing, MVN }
};

const int lookup_table_size = sizeof(lookup_table) / sizeof(lookup_table[0]);

int GetInstructionInfo(const char* mnemonic, Format_t* format, OPCode_t* opcode) {
    for (int i = 0; i < lookup_table_size; i++) {
        if (strcmp(mnemonic, lookup_table[i].mnemonic) == 0) {
            *format = lookup_table[i].format;
            *opcode = lookup_table[i].opcode;
            return 1; // found
        }
    }
    return 0; // not found
}


// Encode ADD instruction: ADD Rd, Rn, Rm
uint32_t encode_dataproc(Instruction instruction, OPCode_t opcode, Format_t formatt) {
    uint32_t cond = CONDITION;       // 1110 = always
    uint32_t I = instruction.is_immediate ? 1 : 0; // Bit 25
    uint32_t S = 0;                  // Do not set flags (bit 20)
    uint32_t operand2 = 0;
    if (instruction.is_immediate) {
        // Simplified immediate encoding: assume imm fits in 8 bits and no rotate needed
        operand2 = instruction.immediate & 0xFF;
        // Note: Full implementation should calculate rotation for larger immediates
    }
    else {
        operand2 = instruction.Rm & 0xF; // Only bottom 4 bits of Rm are used
    }

    return (cond << 28) |       // bits 31-28
        (formatt << 26) |    // bits 27-26
        (I << 25) |          // bit 25: immediate flag
        (opcode << 21) |     // bits 24-21
        (S << 20) |          // bit 20
        (instruction.Rn << 16) | // bits 19-16
        (instruction.Rd << 12) | // bits 15-12
        operand2;            // bits 11-0
}

// Binary output function
void print_binary(uint32_t value) {
    for (int i = 31; i >= 0; i--) {
        printf("%d", (value >> i) & 1);
        if (i % 4 == 0 && i != 0) printf(" ");
    }
    printf("\n");
}

void write_binary_to_file(FILE* outfile, uint32_t value) {
    for (int i = 31; i >= 0; i--) {
        fprintf(outfile, "%d", (value >> i) & 1);
        if (i % 4 == 0 && i != 0) fprintf(outfile, " "); // Optional: spacing
    }
    fprintf(outfile, "\n"); // new line for each instruction
}

int ParseAndEncode(const char* line, FILE* outfile, FILE* outfileBIN) {

    Instruction instr = { 0 };
    OPCode_t opcode;
    Format_t format;
#pragma warning(suppress : 4996)
    sscanf(line, "%s", instr.mnemonic);

    if (!GetInstructionInfo(instr.mnemonic, &format, &opcode)) {
        printf("Instruction not found.\n");
        return 0; // Instruction not found
    }

    char* operand_str = strchr(line, ' '); // find first space
    if (operand_str) operand_str++; // move past the space
    else return 0; // no operands found

    char* token;
    int operand_count = 0;
    int operands[3];   // max 3 registers
    int immediate = 0;
    bool ImmediateFlag = false;


#pragma warning(suppress : 4996)
    token = strtok(operand_str, ", ");
    while (token != NULL) {
        if (token[0] == 'R' || token[0] == 'r') {
            operands[operand_count++] = atoi(token + 1); // parse Rn
        }
        else if (token[0] == '#') {
            immediate = atoi(token + 1);
            ImmediateFlag = true; // found immediate value
        }
#pragma warning(suppress : 4996)
        token = strtok(NULL, ", ");
    }


    if (operand_count == 3) {
        // Format: <mnemonic> Rd, Rn, Rm   (e.g., ADD R1, R2, R3)
        instr.Rd = operands[0];
        instr.Rn = operands[1];
        instr.Rm = operands[2];
        instr.is_immediate = false;

    }
    else if (operand_count == 2 && ImmediateFlag) {
        // Format: <mnemonic> Rd, Rn, #imm (e.g., ADD R1, R2, #3)
        instr.Rd = operands[0];
        instr.Rn = operands[1];
        instr.immediate = immediate;
        instr.is_immediate = true;

    }
    else if (operand_count == 1 && ImmediateFlag) {
        // Format: <mnemonic> Rd, #imm     (e.g., MOV R1, #5)
        instr.Rd = operands[0];
        instr.immediate = immediate;
        instr.is_immediate = true;

    }
    else if (operand_count == 2 && !ImmediateFlag) {
        // Format: <mnemonic> Rd, Rm       (e.g., MOV R1, R2)
        instr.Rd = operands[0];
        instr.Rm = operands[1];
        instr.is_immediate = false;

    }
    else {
        printf("Invalid instruction format.\n");
        return 0;
    }

    if (format == DataProcessing) {
        uint32_t binary = encode_dataproc(instr, opcode, format);
        fprintf(outfile, "%08X\n", binary); // Write binary instruction to output file

        // Write binary string
        write_binary_to_file(outfileBIN, binary);
        return 1; // Successfully encoded
    }
    else {
        printf("This Instruction is not yet supported.\n");
        return 0;
    }

}