// 31   28   27 26  25   24 23 22 21   20   19 18 17 16   15 14 13 12   11 .......... 0
// [COND] 00   I  [ OPCODE ]   S     [   Rn   ]     [   Rd   ]   Operand2
//
// Field breakdown:
// - COND    (4 bits) : Condition field (e.g., 1110 = Always) "31-28"
// - 00      (2 bits) : Bits 27-26 always 00 for data processing "27-26"
// - I       (1 bit)  : Immediate flag (0 = register, 1 = immediate) "25"
// - OPCODE  (4 bits) : Operation code (e.g., 1101 = MOV) "24-21"
// - S       (1 bit)  : Set condition flags? (0 = don't set, 1 = set CPSR) "20"
// - Rn      (4 bits) : First operand register (not used in MOV) "19-16"
// - Rd      (4 bits) : Destination register (e.g., R1) "15-12" 
// - Operand2 (12 bits): Second operand (register or immediate + shift info)   "11-0"
//
// Example encoding for:
//     MOV R1, #5



#include "Assembler.h" 



int main() {

    FILE* infile = fopen("input.asm", "r");
    FILE* outfile = fopen("output.bin", "w");
	FILE* outfileBIN = fopen("outputBIN.bin", "w");

    if (!infile || !outfile) {
        perror("File open failed");
        return 1;
    }

    char line[128];

    while (fgets(line, sizeof(line), infile)) {
        // Remove newline if present
        line[strcspn(line, "\n")] = 0;

        // Skip empty lines
        if (strlen(line) == 0) continue;

        ParseAndEncode(line, outfile, outfileBIN);
    }

    fclose(infile);
    fclose(outfile);
    


    return 0;
}



