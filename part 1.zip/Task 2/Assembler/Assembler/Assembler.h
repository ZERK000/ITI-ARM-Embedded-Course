#pragma once

#ifndef ASSEMBLER_H
#define ASSEMBLER_H

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

// Instruction info struct
typedef struct {
    char mnemonic[8];
    int Rd, Rn, Rm;
	int immediate; // for immediate values
    bool is_immediate; // flag to indicate if Rm is an immediate value
} Instruction;

typedef enum {
    DataProcessing = 0b00,
    MemoryAccess,
    Branches,
    System
}Format_t;

// Data Processing Opcodes
typedef enum {
    AND,
    EOR,
    SUB,
    RSB,
    ADD,
    ADC, // Add with carry
    SBC, // Subtract with carry
    RSC, // Reverse subtract with carry
	TST,// Test bits
	TEQ, // Test for equality
	CMP, // Compare
	CMN, // Compare negative
	ORR, // Logical OR
	MOV = 0b1101, // Move
	//LSL = 0b1101, // Logical Shift Left
	//LSR = 0b1101, // Logical Shift Right
	//ASR = 0b1101, // Arithmetic Shift Right
	//RRX = 0b1101, // Rotate Left
	//ROR = 0b1101, // Rotate Right
	BIC, // Bit clear
	MVN, // Move negative
}OPCode_t;

typedef struct {
    const char* mnemonic;
	Format_t format;
	OPCode_t opcode;

}InstructionLookup;

int GetInstructionInfo(const char* mnemonic, Format_t* format, OPCode_t* opcode);
uint32_t encode_dataproc(Instruction instruction, OPCode_t opcode, Format_t formatt);
void print_binary(uint32_t value);
void write_binary_to_file(FILE* outfile, uint32_t value);

int ParseAndEncode(const char* line, FILE* outfile, FILE* outfileBIN);
// Condition code: Always
#define CONDITION 0b1110



#endif // ASSEMBLER_H
