#include "STD_TYPES.h"
#include "RCCDriver.h" // this should include Interface.h
#include "GPIO_Interface.h"
#include "MNVIC_Private.h"
#include "MNVIC_Interface.h"


int main(void) {

	RCC_SetClock(HSI_ON, ENABLE);    // Optionally disable HSI
	RCC_AHB1EnableClock(RCC_AHB1_GPIOA, ENABLE);


	GPIO_PinMode(PORTA, 0, OUTPUT);
	GPIO_OutputPinConfigure(PORTA, 0, PUSH_PULL, LOW_SPEED);

	MNVIC_voidEnable(6);
	MNVIC_voidSetPendingFlag(6);

	while (1)
	{
//		GPIO_SetPinValueAtomic(PORTA, 5, HIGH);
//		for (volatile u32 i = 0; i < 100000; i++);
//		GPIO_SetPinValueAtomic(PORTA, 5, LOW);
//		for (volatile u32 i = 0; i < 100000; i++);
	}
}


EXTI0_IRQHandler()
{
	GPIO_SetPinValue(PORTA,0,HIGH);
}
