#ifndef RCC_INTERFACE_H
#define RCC_INTERFACE_H

#include "STD_TYPES.h"

#define DISABLE 0
#define ENABLE  1

/////////////////// RCC_CR options /////////////////
// offset = 0x00
#define HSI_ON 0
#define HSE_ON 1
#define HSE_BYP 2
#define CSS_ON 3
#define PLL_ON 4
#define PLLI2S_ON 5




void RCC_SetClock(u8 clock, u8 state);



// SYSCLK options
#define RCC_SYSCLK_HSI   0
#define RCC_SYSCLK_HSE   1
#define RCC_SYSCLK_PLL   2

// AHB Prescaler options (HPRE)
#define RCC_AHB_PRESCALER_DIV1   0x0
#define RCC_AHB_PRESCALER_DIV2   0x8
#define RCC_AHB_PRESCALER_DIV4   0x9
#define RCC_AHB_PRESCALER_DIV8   0xA
// ... up to 0xF for DIV512

// APB1/2 Prescaler options (PPRE1, PPRE2)
#define RCC_APB_PRESCALER_DIV1   0x0
#define RCC_APB_PRESCALER_DIV2   0x4
#define RCC_APB_PRESCALER_DIV4   0x5
#define RCC_APB_PRESCALER_DIV8   0x6
#define RCC_APB_PRESCALER_DIV16  0x7

// Function prototype
void RCC_ConfigBuses(u8 sysclk, u8 ahb_prescaler, u8 apb1_prescaler, u8 apb2_prescaler);

// AHB1 Peripheral Enable Bits
#define RCC_AHB1_GPIOA    0
#define RCC_AHB1_GPIOB    1
#define RCC_AHB1_GPIOC    2
#define RCC_AHB1_GPIOD    3
#define RCC_AHB1_GPIOE    4
#define RCC_AHB1_GPIOH    7
#define RCC_AHB1_CRC      12
#define RCC_AHB1_DMA1     21
#define RCC_AHB1_DMA2     22

// Function prototype
void RCC_AHB1EnableClock(u8 peripheral, u8 state);


#endif
