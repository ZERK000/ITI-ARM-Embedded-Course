#include "RCCDriver.h" // this should include Interface.h


int main(void) {
	RCC_SetClock(HSE_ON, DISABLE);     // Enable HSE
    RCC_SetClock(PLL_ON, DISABLE);     // Enable PLL
    RCC_SetClock(HSI_ON, DISABLE);    // Optionally disable HSI



    while (1) {
        // Application code
    }
}
