/*
 * SevenSegment.c
 *
 *  Created on: Jul 16, 2025
 *      Author: Ziad
 */
#include "SevenSegment.h"


Port_t SEG_PORT =   PORTA;

// Array of segments for digits 0�9 (common cathode logic)
static const u8 segment_map[10] = {
		0b00111111, // 0
		0b00000110, // 1
		0b01011011, // 2
		0b01001111, // 3
		0b01100110, // 4
		0b01101101, // 5
		0b01111101, // 6
		0b00000111, // 7
		0b01111111, // 8
		0b01101111  // 9
};

void SEGMENT_voidInit(void)
{
	// Initialize the segment pins as output
	GPIO_PinMode(SEG_PORT, SEG_A_PIN, OUTPUT);
	GPIO_PinMode(SEG_PORT, SEG_B_PIN, OUTPUT);
	GPIO_PinMode(SEG_PORT, SEG_C_PIN, OUTPUT);
	GPIO_PinMode(SEG_PORT, SEG_D_PIN, OUTPUT);
	GPIO_PinMode(SEG_PORT, SEG_E_PIN, OUTPUT);
	GPIO_PinMode(SEG_PORT, SEG_F_PIN, OUTPUT);
	GPIO_PinMode(SEG_PORT, SEG_G_PIN, OUTPUT);
}

void SEGMENT_voidDisplayDigit(u8 Digit)
{
	if (Digit > 9) return;

	u8 pattern = segment_map[Digit];

	GPIO_SetPinValue(SEG_PORT, SEG_A_PIN, 0);
	GPIO_SetPinValue(SEG_PORT, SEG_B_PIN, 0);
	GPIO_SetPinValue(SEG_PORT, SEG_C_PIN, 0);
	GPIO_SetPinValue(SEG_PORT, SEG_D_PIN, 0);
	GPIO_SetPinValue(SEG_PORT, SEG_E_PIN, 0);
	GPIO_SetPinValue(SEG_PORT, SEG_F_PIN, 0);
	GPIO_SetPinValue(SEG_PORT, SEG_G_PIN, 0);

	GPIO_SetPinValue(SEG_PORT, SEG_A_PIN, (pattern >> 0) & 0x1);
	GPIO_SetPinValue(SEG_PORT, SEG_B_PIN, (pattern >> 1) & 0x1);
	GPIO_SetPinValue(SEG_PORT, SEG_C_PIN, (pattern >> 2) & 0x1);
	GPIO_SetPinValue(SEG_PORT, SEG_D_PIN, (pattern >> 3) & 0x1);
	GPIO_SetPinValue(SEG_PORT, SEG_E_PIN, (pattern >> 4) & 0x1);
	GPIO_SetPinValue(SEG_PORT, SEG_F_PIN, (pattern >> 5) & 0x1);
	GPIO_SetPinValue(SEG_PORT, SEG_G_PIN, (pattern >> 6) & 0x1);
}

